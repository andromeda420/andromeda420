# script.extendedinfo
Wraith Kodi Add-on
